package com.test.palindrome.controller;

import java.time.LocalDateTime;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.test.palindrome.exception.PalindromeInvalidRequestException;
import com.test.palindrome.exception.PalindromeNoRecordFoundException;
import com.test.palindrome.model.ExceptionResponse;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ExceptionController extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(PalindromeInvalidRequestException.class)
	  @ResponseStatus(HttpStatus.BAD_REQUEST)
	  public final ResponseEntity<ExceptionResponse> emptyRequesExceptiont(
			  PalindromeInvalidRequestException exception,
			  WebRequest request
	  ) {
		 
		 LocalDateTime now = LocalDateTime.now();

		  ExceptionResponse exceptionResponse = 
		  new ExceptionResponse("Invalid request.Please enter a valid letter string",now);
		  
		  return new ResponseEntity<ExceptionResponse>(exceptionResponse,
				  new HttpHeaders(), HttpStatus.BAD_REQUEST);
	}
	
	
	@ExceptionHandler(PalindromeNoRecordFoundException.class)
	  @ResponseStatus(HttpStatus.NOT_FOUND)
	  public final ResponseEntity<ExceptionResponse> emptyRequesExceptiont(
			  PalindromeNoRecordFoundException exception,
			  WebRequest request
	  ) { 
		 LocalDateTime now = LocalDateTime.now();

		  ExceptionResponse exceptionResponse = 
		  new ExceptionResponse("No plaindrome found. Please try to add data again",now);
		  
		  return new ResponseEntity<ExceptionResponse>(exceptionResponse,
				  new HttpHeaders(), HttpStatus.NOT_FOUND);
	}
	
	
}
