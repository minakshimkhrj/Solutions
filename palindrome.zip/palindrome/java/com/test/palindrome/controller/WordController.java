package com.test.palindrome.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.palindrome.PalindromeImpl;
import com.test.palindrome.exception.PalindromeInvalidRequestException;
import com.test.palindrome.exception.PalindromeNoRecordFoundException;
import com.test.palindrome.model.Sentence;
import com.test.palindrome.model.Word;
import com.test.palindrome.repositories.WordRepository;

@RestController
public class WordController {
	
	@Autowired
	public WordRepository wordRepository;
	@Autowired
	public PalindromeImpl palindromeImpl;
	
	@GetMapping(value = "/getAllWords")
	public List<Word> getAllWords(){
		List<Word> allPalindromes =  wordRepository.findAll();
		if(allPalindromes.size()<0) {
			throw new PalindromeNoRecordFoundException();
		}
		return allPalindromes;		
	}
	
	@PostMapping(value = "/addLongestPalindrome")
	public String addWord(@RequestBody Sentence sentence) {
		if(sentence.getValue() == null || sentence.getValue().equals("")) {
			throw new PalindromeInvalidRequestException();
		}
		Word word = palindromeImpl.findLongestPalindrome(sentence);
		Word insertedWord = wordRepository.insert(word);
		return ("Longest Palindrome Added is : "+insertedWord.getValue());		
	}
	

}
