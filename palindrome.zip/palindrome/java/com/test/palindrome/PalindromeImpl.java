package com.test.palindrome;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.test.palindrome.exception.PalindromeInvalidRequestException;
import com.test.palindrome.exception.PalindromeNoRecordFoundException;
import com.test.palindrome.model.Sentence;
import com.test.palindrome.model.Word;

@Component
public class PalindromeImpl {
	
	@Autowired
	private Word word;
	
	
	private List<String> getWords(Sentence sentences) {
		String newString = sentences.getValue().replaceAll("[^A-Za-z]", " ");
		String[] word = newString.split(" ");
		List<String> allWords = new ArrayList<String> ();
		for(int i=0 ; i<word.length; i++) {
			allWords.add(word[i]);
		}
		return allWords;
	}
	
	private boolean isPalindrome(String word) {
		StringBuilder sb = new StringBuilder(word.toLowerCase());
		String reverseWord = sb.reverse().toString();
		return word.toLowerCase().equals(reverseWord);
	}
		
	
	public Word findLongestPalindrome(Sentence sentences) {		 
		List<String> allWords= getWords(sentences);
		int maxWordLength = 0;	
		String maxWord = "";
		if(allWords.size() > 0) {			
			for(int i = 0; i < allWords.size(); i++) {
				if(isPalindrome(allWords.get(i))) {
					int currentWordLength = allWords.get(i).length();
					String currentWord = allWords.get(i);
					if(currentWordLength > maxWordLength) {
						maxWord = currentWord;
						maxWordLength = currentWordLength;
					}
				}
			}
		}else {
			throw new PalindromeInvalidRequestException();
		}
		System.out.println("maxWord == "+maxWord);
		if(maxWord != null && !(maxWord.equals(""))) {
			word.setValue(maxWord);
		}else {
			throw new PalindromeNoRecordFoundException();
		}
		return word;
		
	}

}
