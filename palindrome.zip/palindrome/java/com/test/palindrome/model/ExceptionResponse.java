package com.test.palindrome.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ExceptionResponse {
	
	public ExceptionResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
		
	public ExceptionResponse(String errorMessage, LocalDateTime timestamp) {
		super();
		this.errorMessage = errorMessage;
		this.timestamp = timestamp;
	}


	private String errorMessage;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    private LocalDateTime timestamp;
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

}
