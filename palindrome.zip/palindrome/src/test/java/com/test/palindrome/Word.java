package com.test.palindrome;

public class Word {

}
