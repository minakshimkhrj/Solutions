package com.test.palindrome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PalindromeApplicationTests {

	@Test
	void contextLoads() {
	}

}
